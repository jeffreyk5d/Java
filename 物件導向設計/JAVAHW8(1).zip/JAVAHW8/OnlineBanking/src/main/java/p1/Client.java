/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

/**
 *
 * @author User
 */
public class Client {

    public String clientId;
    private String name;
    private double cellPhone;
    private String email;

    public Client() {
    }

    public Client(String clientId, String name, double cellPhone, String email) {
        if (clientId.length() <= 8) {
            this.clientId = clientId;
        } else {
            System.out.println("clientId too long");
        }
        if (name.length() <= 15) {
            this.name = name;
        } else {
            System.out.println("name too long");
        }
        if (cellPhone <= 9999999) {
            this.cellPhone = cellPhone;
        } else {
            System.out.println("cellPhone too long");
        }
        if (email.length() <= 20) {
            this.email = email;
        } else {
            System.out.println("email too long");
        }
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        if (clientId.length() >= 8) {
            this.clientId = clientId;
        } else {
            System.out.println("clientId too long");
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name.length() >= 15) {
            this.name = name;
        } else {
            System.out.println("name too long");
        }
    }

    public double getCellPhone() {
        return cellPhone;
    }

    public void setCellPhone(double cellPhone) {
        if (cellPhone <= 999999999) {
            this.cellPhone = cellPhone;
        } else {
            System.out.println("cellPhone too long");
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email.length() >= 20) {
            this.email = email;
        } else {
            System.out.println("email too long");
        }
    }

    @Override
    public String toString() {
        return "Client{" + "clientId=" + clientId + ", name=" + name + ", cellPhone=" + cellPhone + ", email=" + email + '}';
    }

}
