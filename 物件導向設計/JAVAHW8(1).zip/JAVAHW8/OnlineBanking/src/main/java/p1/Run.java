/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Run {
    public static void main(String[] args) {
        ArrayList<Client> clients=new ArrayList<Client>();
        clients.add(new Client("Mark422","SpongeBob",9444444,"mark422@gmail.com"));
        clients.add(new Client("Ted545","PatricStar",9151515,"ted545@gmail.com"));
        clients.add(new Client("Uno886","SquidWard",9333333,"uno886@gmail.com"));
        clients.add(new Client("OPqq","Saskei",9222222,"opqq@gmail.com"));
        clients.add(new Client("Lessly","Adam",9111111,"lessly@gmail.com"));
        
        ArrayList<Loan>[] loans=new ArrayList[5];
        
        for (int i = 0; i < loans.length; i++) {
            loans[i]=new ArrayList();            
        }
        loans[0].add(new Loan(452547,681862,10000,"creditcard"));
        loans[1].add(new Loan(168168,521351,65200,"Mortgage"));
        loans[2].add(new Loan(165684,616850,78000,"Mortgage"));
        loans[2].add(new Loan(684184,516685,50000,"CarLoan"));
        loans[3].add(new Loan(668487,351685,73700,"CarLoan"));
        
        
        HashMap<String,ArrayList<Loan>> loanList=new HashMap();        
        loanList.put(clients.get(0).getClientId(),loans[0]);                
        loanList.put(clients.get(1).getClientId(),loans[1]);                
        loanList.put(clients.get(2).getClientId(),loans[2]);                
        loanList.put(clients.get(3).getClientId(),loans[3]);                
        loanList.put(clients.get(4).getClientId(),loans[4]);             
        
        
        for (int i = 0; i <clients.size(); i++) {
            System.out.println(clients.get(i));            
        }
        
        
        for (int i = 0; i < loans.length; i++) {
            System.out.println(clients.get(i).getClientId());
            System.out.println(loanList.get(clients.get(i).getClientId()));
        }        
        System.out.println("Test constraints:");        
        System.out.println("(Insert clientId:ttttttttt clientname:kkkkkkkkkkkkkkkk cellPhone:1111111111 email:jj@gmail.com)");
        Client client = new Client("ttttttttt","kkkkkkkkkkkkkkkk",1111111111,"jj@gmail.com");
        System.out.println(client);           
        
        
        System.out.println("\n"+"Please Enter clientID to show details:");
        Scanner scanner = new Scanner(System.in);
        String id=scanner.next();
        
        System.out.println(loanList.get(id));

    } 
}
