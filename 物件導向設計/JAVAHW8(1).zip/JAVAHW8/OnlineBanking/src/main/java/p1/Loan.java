/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

/**
 *
 * @author User
 */
public class Loan {

    private String clientId;
    private double accountFrom;
    private double accountTo;
    private double amount;
    private String mark;

    public Loan() {
    }

    public Loan(double accountFrom, double accountTo, double amount, String mark) {
        if (accountFrom <= 999999) {
            this.accountFrom = accountFrom;
        } else {
            System.out.println("accountFrom too long");
        }
        if (accountTo <= 999999) {
            this.accountTo = accountTo;
        } else {
            System.out.println("accountTo too long");
        }
        if (amount <= 999999) {
            this.amount = amount;
        } else {
            System.out.println("amount too long");
        }
        if (mark.length() <= 15) {
            this.mark = mark;
        } else {
            System.out.println("mark too long");
        }
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        if (mark.length() <= 15) {
            this.mark = mark;
        } else {
            System.out.println("mark too long");
        }
    }

    public double getAccountFrom() {
        return accountFrom;
    }

    public void setAccountFrom(double accountFrom) {
        if (accountFrom < 999999) {
            this.accountFrom = accountFrom;
        } else {
            System.out.println("accountFrom too long");
        }
    }

    public double getAccountTo() {
        return accountTo;
    }

    public void setAccountTo(double accountTo) {
        if (accountTo < 999999) {
            this.accountTo = accountTo;
        } else {
            System.out.println("accountTo too long");
        }
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        if (amount < 999999) {
            this.amount = amount;
        } else {
            System.out.println("amount too long");
        }
    }

    @Override
    public String toString() {
        return "Loan{" + "accountFrom=" + accountFrom + ", accountTo=" + accountTo + ", amount=" + amount + ", mark=" + mark + '}';
    }
}
