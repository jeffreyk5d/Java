/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TTUCSE
 */
public class MM {
    public static void main(String[] args) {
        int[] array={88,45,2,34};
        System.out.println("max="+Maths.max(array));
    }
}
