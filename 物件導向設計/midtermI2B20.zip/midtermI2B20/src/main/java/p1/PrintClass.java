/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import java.util.Scanner;

/**
 *
 * @author TTUCSE
 */
public class PrintClass {

    public static void scannerPrint() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Enter: ");
            int n = scanner.nextInt();
               
            if (n < 0) {
                return;
            }
            for (int i = 1; i <= 3 * n + 1; i = i + 3) {
                System.out.print(i);
                System.out.print(" ");
            }
            System.out.println("");
        }
    }
}
