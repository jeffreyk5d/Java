/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3;

/**
 *
 * @author TTUCSE
 */
public class Child extends Parent{
    private int x = 2;

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }
    public int getSuperX() {
        return super.getX();
    }
    public int getSuperX2() {
        return super.x;
    }
}
