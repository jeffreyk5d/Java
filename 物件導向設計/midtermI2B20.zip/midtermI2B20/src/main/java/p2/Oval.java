/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;

/**
 *
 * @author TTUCSE
 */
public class Oval {
    private double semiMajor;
    private double semiMinor;
    
    private static int count;

    public Oval(double semiMajor, double semiMinor) {
        this.semiMajor = semiMajor;
        this.semiMinor = semiMinor;
        count++;
    }

    public Oval() {
        count++;
    }
    
    public double caluArea() {
        return Math.PI * semiMajor * semiMinor;
    }

    public double getSemiMajor() {
        return semiMajor;
    }

    public void setSemiMajor(double semiMajor) {
        this.semiMajor = semiMajor;
    }

    public double getSemiMinor() {
        return semiMinor;
    }

    public void setSemiMinor(double semiMinor) {
        this.semiMinor = semiMinor;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Oval.count = count;
    }

    @Override
    public String toString() {
        return "TestClass{" + "semi-major=" + semiMajor + ", semi-minor=" + semiMinor + ", Area=" + caluArea() + '}';
    }
}
