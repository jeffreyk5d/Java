/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;

/**
 *
 * @author TTUCSE
 */
public class TestClass {
    public static void main(String[] args) {
        Oval oval1 = new Oval(3, 2);
        Oval oval2 = new Oval(10, 5);
        
        System.out.print("Oval1: ");
        System.out.println(oval1);
        
        System.out.println("");
        
        System.out.print("Oval2: ");
        System.out.println(oval2);
        
        System.out.print("total count:");
        System.out.println(Oval.getCount());
    }
}
