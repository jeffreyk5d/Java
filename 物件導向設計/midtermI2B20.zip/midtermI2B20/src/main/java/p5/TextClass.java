/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5;

/**
 *
 * @author TTUCSE
 */
public class TextClass {
    public static void main(String[] args) {
        Car car = new Car("8888-KFC", 99999, "1234-5678", 4, 100);
        Truck truck = new Truck("8888-TTU", 999999, "1234-5679", 12, 15);
        
        System.out.println("Car:");
        System.out.println(car);
        
        System.out.println("Truck:");
        System.out.println(truck);
    }
}
