/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5;

/**
 *
 * @author TTUCSE
 */
public class Truck extends Vehicle{
    private int no_of_axles;
    private float tonnage;

    public Truck(String license_plate_no, int price, String vehicle_id, int no_of_axles, float tonnage) {
        this.no_of_axles = no_of_axles;
        this.tonnage = tonnage;
        super.license_plate_no = license_plate_no;
        super.price = price;
        super.vehicle_id = vehicle_id;
    }
    
    public int getNo_of_axles() {
        return no_of_axles;
    }

    public void setNo_of_axles(int no_of_axles) {
        this.no_of_axles = no_of_axles;
    }

    public float getTonnage() {
        return tonnage;
    }

    public void setTonnage(float tonnage) {
        this.tonnage = tonnage;
    }

    @Override
    public String toString() {
        return "Truck{" + super.toString() + ", no_of_axles=" + no_of_axles + ", tonnage=" + tonnage + '}';
    }
}
