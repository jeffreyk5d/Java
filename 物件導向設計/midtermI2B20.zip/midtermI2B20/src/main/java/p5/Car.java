/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5;

/**
 *
 * @author TTUCSE
 */
public class Car extends Vehicle {
    private int no_of_passengers;
    private int max_speed;

    public Car(String license_plate_no, int price, String vehicle_id, int no_of_passengers, int max_speed) {
        this.no_of_passengers = no_of_passengers;
        this.max_speed = max_speed;
        super.license_plate_no = license_plate_no;
        super.price = price;
        super.vehicle_id = vehicle_id;
    }
    
    public int getNo_of_passengers() {
        return no_of_passengers;
    }

    public void setNo_of_passengers(int no_of_passengers) {
        this.no_of_passengers = no_of_passengers;
    }

    public int getMax_speed() {
        return max_speed;
    }

    public void setMax_speed(int max_speed) {
        this.max_speed = max_speed;
    }

    @Override
    public String toString() {
        return "Car{" + super.toString() + ", no_of_passengers=" + no_of_passengers + ", max_speed=" + max_speed + '}';
    }
}
