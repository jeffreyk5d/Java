/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p4;

/**
 *
 * @author TTUCSE
 */
public class TestDeck {
    public static void main(String[] args) {
        System.out.println("Card測試");
        Card card = new Card((byte)1, (byte)3);
        Card card2 = new Card((byte)0, (byte)2);
        System.out.print("Card1: ");
        System.out.println(card);

        System.out.print("Card2: ");
        System.out.println(card2);
        System.out.println("");
        
        System.out.println("Deck測試");
        Deck deck = new Deck();
        
        System.out.println("洗牌前: ");
        System.out.print(deck);
        
        System.out.println("");
        deck.shuffle();
        
        System.out.println("洗牌後: ");
        System.out.print(deck);
    }
}
