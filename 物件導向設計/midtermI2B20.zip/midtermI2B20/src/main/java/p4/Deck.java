/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p4;

import java.util.Collections;
import java.util.ArrayList;

/**
 *
 * @author TTUCSE
 */
public class Deck {
    ArrayList<Card> cards = new ArrayList<>();
    
    /**
     * 一組照順序排列的牌組
     */
    public Deck() {
        for (int i = 0; i < 52; i++) {
            cards.add(new Card((byte)(i / 13), (byte)(i % 13)));
        }
    }
    
//    /**
//     * 洗牌2
//     */
//    public void shuffle2() {
//        for (int i = 0; i < getCount(); i++) {
//            int index = (int)Math.round(Math.random() * deck.size() - 1);  // 與隨機位置交換
//            Card temp = (Card)deck.get(index);
//            deck.set(index, deck.get(i));
//            deck.set(i, temp);
//        }
//    }
    
    /**
     * 洗牌
     */
    public void shuffle() {
        Collections.shuffle(cards);
    }
    
    /**
     * 發牌
     * @return 卡片
     */
    public Card deal() {
        if (cards.isEmpty()) 
            return null;
        Card ret = (Card)cards.get(0);
        cards.remove(0);
        return ret;
    }

    /**
     * 剩餘卡片數量
     * @return 剩餘數量
     */
    public int getCount() {
        return cards.size();
    }
    
    /**
     * 轉為字串
     * @return 整組牌字串
     */
    @Override
    public String toString() {
        String ret = "";
        for (int i = 0; i < cards.size(); i++) {
            if (i % 13 == 0 && i != 0) 
                ret += '\n';
            ret = ret + cards.get(i) + ' ';
        }
        ret += '\n';
        
        return ret;
    }
}
