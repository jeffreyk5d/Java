/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p4;

/**
 *
 * @author TTUCSE
 */
public class Card {
    private byte rank;
    private byte suit;
    
    public static final String[] RANKS = {"Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};
    public static final String[] SUITS = {"Spades", "Hearts", "Diamonds", "Clubs"};

    public Card(byte suit, byte rank) {
        this.rank = rank;
        this.suit = suit;
    }

    public Card() {
    }

    public byte getRank() {
        return rank;
    }

    public void setRank(byte rank) {
        this.rank = rank;
    }

    public byte getSuit() {
        return suit;
    }

    public void setSuit(byte suit) {
        this.suit = suit;
    }
    
    @Override
    public String toString() {
        return "Card{" + SUITS[suit] + ", " + RANKS[rank] + '}';
    }
}
