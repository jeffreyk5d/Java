
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;
import javax.swing.Timer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author User
 */
public class GamePlay extends JPanel implements KeyListener, ActionListener {

    private boolean play = false;
    private int score = 0;
    private int totalBricks = 48;

    private Timer timer;
    private int delay = 6;

    private int playerX = 310;
    private int ballposX = 120;
    private int ballposY = 350;
    private int ballXdir = -2;
    private int ballYdir = -3;
    private Brick brick;
     static int flag=0;

    public GamePlay() {
        brick = new Brick(4, 12);
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        timer = new Timer(delay, this);   //???
        timer.start();                 //???
    }

    public void paint(Graphics g) {
        
        //背景
        g.setColor(Color.black);
        g.fillRect(1, 1, 740, 592);
        //黃色邊界 上左右都有  ((下邊界 因為要讓球掉下去來結束遊戲所以沒有
        g.setColor(Color.yellow);
        g.fillRect(0, 0, 3, 592); //左邊界
        g.fillRect(0, 0, 737, 3); //上邊界
        g.fillRect(730, 0, 3, 592);//右邊界        
        if (!play&&flag==0) {
            g.setFont(new Font("serif", Font.BOLD, 30));
            g.drawString("Press left or right to Start", 200, 400);
            flag=1;
        }

        //竿子
        g.setColor(Color.RED);
        g.fillRect(playerX, 550, 100, 8);
        //球
        g.setColor(Color.yellow);
        g.fillOval(ballposX, ballposY, 20, 20);

        //畫磚塊
        brick.draw((Graphics2D) g);
        //畫分數
        g.setColor(Color.white);
        g.setFont(new Font("serif", Font.BOLD, 25));
        g.drawString("" + score, 690, 30);
        if (ballposY > 570) {
            play = false;
            ballXdir = 0;
            ballYdir = 0;
            g.setColor(Color.red);
            g.setFont(new Font("serif", Font.BOLD, 30));
            g.drawString("Game Over score:" + score, 230, 250);
            g.setFont(new Font("serif", Font.BOLD, 20));
            g.drawString("Press Enter to Restart", 230, 300);
        }
        if (totalBricks==0) {
            play = false;
            ballXdir = 0;
            ballYdir = 0;
            g.setColor(Color.red);
            g.setFont(new Font("serif", Font.BOLD, 30));
            g.drawString("You win!! score:" + score, 230, 250);
            g.setFont(new Font("serif", Font.BOLD, 20));
            g.drawString("Press Enter to Restart", 230, 300);
        }
        g.dispose();//???
    }

    //當按下左右按鍵竿子會做的事
    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            if (playerX >= 620) {
                playerX = 620;
            } else {
                moveRight();
            }
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            if (playerX <= 10) {
                playerX = 10;
            } else {
                moveLeft();
            }
        }
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            if (!play) {
                play = true;
                ballposX = 120;
                ballposY = 350;
                ballXdir = -3;
                ballYdir = -5;
                playerX = 310;
                score = 0;
                totalBricks = 48;
                brick = new Brick(4, 12);
            }
        }
    }

    private void moveRight() {
        play = true;
        playerX += 20;
    }

    private void moveLeft() {
        play = true;
        playerX -= 20;
    }

    //當按下按鍵執行的事情 ((在這裡是重新再畫
    @Override
    public void actionPerformed(ActionEvent e) {
        timer.start();//???
        if (play) {
            //創一個包裹著球的矩形 和 另一個包裹竿子的矩形 用來判斷他們是否有碰觸 ((包裹:x y位置，長寬一樣就好 另外 我們沒給他們上色 所以不用擔心看不看的到的問題
            if (new Rectangle(ballposX, ballposY, 20, 20).intersects(new Rectangle(playerX, 550, 100, 8))) {
                ballYdir = -ballYdir;
            }

            A:
            for (int i = 0; i < brick.map.length; i++) {
                for (int j = 0; j < brick.map[0].length; j++) {
                    if (brick.map[i][j] > 0) {//若磚塊還在 就有這些數值 給另一個函式作畫
                        int brickX = j * brick.brickWidth + 70;//+20是左邊和牆壁的空隙
                        int brickY = i * brick.brickHeight + 50;//上面的
                        int brickWidth = brick.brickWidth;//為了方便創的 不然還要 點來點去
                        int brickHeight = brick.brickHeight;///同上

                        Rectangle rect = new Rectangle(brickX, brickY, brickWidth, brickHeight);//和竿子一樣，創個位置相同的磚塊，判斷是否有碰到球
                        Rectangle ballRect = new Rectangle(ballposX, ballposY, 20, 20);
                        Rectangle brickRect = rect;
                        if (ballRect.intersects(brickRect)) {
                            brick.setBrickValue(0, i, j);
                            totalBricks--;
                            score += 5;
                            if (ballposX + 20 <= brickRect.x || ballposX >= brickRect.x + brickRect.width) {//找出球哪裡和磚塊接觸 判斷球該往哪個方向
                                ballXdir = -ballXdir;
                            } else {
                                ballYdir = -ballYdir;
                            }
                            break A; //???
                        }
                    }
                }

            }

            ballposX += ballXdir;
            ballposY += ballYdir;
            if (ballposX < 0) {
                ballXdir = -ballXdir;
            }
            if (ballposY < 0) {//碰到上邊界 球y方向改變
                ballYdir = -ballYdir;
            }
            if (ballposX > 710) {
                ballXdir = -ballXdir;
            }
            if (ballposY > 670) {
                ballYdir = -ballYdir;
            }
        }
        repaint();//這函式可能員原本就設定成沒人叫他停他就一直執行吧
        //??一直執行??只執行一次??
    }

    //這些沒用到 我們只要用判斷按下哪個按鍵的函式
    //怕出錯 所以我們把這些留著
    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

}
