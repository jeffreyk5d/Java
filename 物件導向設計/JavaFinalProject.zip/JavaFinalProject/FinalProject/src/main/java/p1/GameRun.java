/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import java.awt.Color;
import static java.lang.System.in;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

/**
 *
 * @author User
 */
public class GameRun extends javax.swing.JFrame {

    /**
     * Creates new form GuessingGame
     */
    public static int count;
    public static int d = 0;
    private ArrayList<Integer> ans = new ArrayList<>();
    int total;

    public GameRun() {
        initComponents();
        super.setResizable(false);
        textArea.setEditable(false);
        AB.setEditable(false);
        this.createAns();
        if (FrontPage.choice == 1) {
            d = 4;
        } else if (FrontPage.choice == 2) {
            d = 4;
        } else if (FrontPage.choice == 3) {
            d = 6;
        }

        guess.setDocument(new NumberLenghtLimitedDmt(d));
    }

    public void comparisonEasy(int number) {
        int A = 0, B = 0;
        int[] aguess = {1, 2, 3, 4};
        aguess[0] = number / 1000;
        aguess[1] = (number % 1000) / 100;
        aguess[2] = (number % 100) / 10;
        aguess[3] = (number % 10);
        int[] tag = {0, 0, 0, 0};
        for (int i = 0; i < aguess.length; i++) {
            if (aguess[i] == ans.get(i)) {
                A++;
                tag[i] = 1;
            }
        }
        for (int i = 0; i < aguess.length; i++) {
            for (int j = 0; j < aguess.length; j++) {
                if (aguess[i] == ans.get(j) && tag[j] != 1) {
                    tag[j] = 1;
                    B++;
                    break;
                }
            }
        }
        if (A == 4) {
            AB.append("You Win!!");
        } else {
            AB.append("A= " + A + " B= " + B + "\n");
        }
    }

    public void comparisonNormal(int number) {
        int A = 0, B = 0;
        int[] aguess = {1, 2, 3, 4};
        aguess[0] = number / 1000;
        aguess[1] = (number % 1000) / 100;
        aguess[2] = (number % 100) / 10;
        aguess[3] = (number % 10);
        //找A
        int[] tag = {0, 0, 0, 0};
        for (int i = 0; i < aguess.length; i++) {
            if (aguess[i] == ans.get(i)) {
                A++;
                tag[i] = 1;
            }
        }
        for (int i = 0; i < aguess.length; i++) {
            for (int j = 0; j < aguess.length; j++) {
                if (aguess[i] == ans.get(j) && tag[j] != 1) {
                    tag[j] = 1;
                    B++;
                    break;
                }
            }
        }

        if (A == 4) {
            AB.append("You Win!!");
        } else {
            AB.append("A= " + A + " B= " + B + "\n");
        }
    }

    public void comparisonHard(int number) {
        int A = 0, B = 0;
        int[] aguess = {1, 2, 3, 4, 5, 6};
        aguess[0] = number / 100000;
        aguess[1] = (number % 100000) / 10000;
        aguess[2] = (number % 10000) / 1000;
        aguess[3] = (number % 1000) / 100;
        aguess[4] = (number % 100) / 10;
        aguess[5] = (number % 10);
        //找A
        int[] tag = {0, 0, 0, 0, 0, 0};
        for (int i = 0; i < aguess.length; i++) {
            if (aguess[i] == ans.get(i)) {
                A++;
                tag[i] = 1;
            }
        }
        for (int i = 0; i < aguess.length; i++) {
            for (int j = 0; j < aguess.length; j++) {
                if (aguess[i] == ans.get(j) && tag[j] != 1) {
                    tag[j] = 1;
                    B++;
                    break;
                }
            }
        }

        if (A == 6) {
            AB.append("You Win!!");
        } else {
            AB.append("A= " + A + " B= " + B + "\n");
        }
    }

    public class NumberLenghtLimitedDmt extends PlainDocument {

        private int limit;

        public NumberLenghtLimitedDmt(int limit) {
            super();
            this.limit = limit;
        }

        @Override
        public void insertString(int offset, String str, AttributeSet attr)
                throws BadLocationException {
            if (str == null) {
                return;
            }
            if ((getLength() + str.length()) <= limit) {

                char[] upper = str.toCharArray();
                int length = 0;
                for (int i = 0; i < upper.length; i++) {
                    if (upper[i] >= '0' && upper[i] <= '9') {
                        upper[length++] = upper[i];
                    }
                }
                super.insertString(offset, new String(upper, 0, length), attr);
            }
        }
    }

    public void easyAns() {
        //創造密碼0~9選4個
        ArrayList<Integer> storage = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            storage.add(i);
        }
        Collections.shuffle(storage);//0~9順序洗亂            
        this.ans.clear();
        //取a[0]~a[3]四個當作答案            
        for (int i = 0; i < 4; i++) {
            this.ans.add(storage.get(i));
        }
        this.total = this.ans.get(0) * 1000 + this.ans.get(1) * 100 + this.ans.get(2) * 10 + this.ans.get(3);
        if (total < 1000) {
            System.out.println("ans=0" + total);
        } else {
            System.out.println("ans=" + total);
        }
    }
//好像可以合併

    public void normalAns() {
        this.ans.clear();
        Random random = new Random();
        int[] ra = {random.nextInt(10), random.nextInt(10), random.nextInt(10), random.nextInt(10)};
        for (int i = 0; i < ra.length; i++) {
            ans.add(ra[i]);
        }
        this.total = this.ans.get(0) * 1000 + this.ans.get(1) * 100 + this.ans.get(2) * 10 + this.ans.get(3);
        if (total < 1000) {
            System.out.println("ans=0" + total);
        } else if (total < 100) {
            System.out.println("ans=00" + total);
        } else if (total < 10) {
            System.out.println("ans=000" + total);
        } else {
            System.out.println("ans=" + total);
        }
    }

    public void hardAns() {
        this.ans.clear();
        Random random = new Random();

        int[] ra = {random.nextInt(10), random.nextInt(10), random.nextInt(10), random.nextInt(10), random.nextInt(10), random.nextInt(10)};
        for (int i = 0; i < ra.length; i++) {
            ans.add(ra[i]);
        }
        this.total = this.ans.get(0) * 100000 + this.ans.get(1) * 10000 + this.ans.get(2) * 1000 + this.ans.get(3) * 100 + this.ans.get(4) * 10 + this.ans.get(5);
        System.out.println(total);
    }
//合併

    public void createAns() {
        if (FrontPage.choice == 1) {
            easyAns();
        } else if (FrontPage.choice == 2) {
            normalAns();
        } else if (FrontPage.choice == 3) {
            hardAns();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        midPane = new javax.swing.JPanel();
        guessPane = new javax.swing.JScrollPane();
        textArea = new javax.swing.JTextArea();
        ansPane = new javax.swing.JScrollPane();
        AB = new javax.swing.JTextArea();
        tenChance = new javax.swing.JLabel();
        noteReminder = new javax.swing.JLabel();
        topPane = new javax.swing.JPanel();
        topic = new javax.swing.JLabel();
        bottomPane = new javax.swing.JPanel();
        guess = new javax.swing.JTextField();
        send = new javax.swing.JButton();
        newGame = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        home = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        rule = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        midPane.setBackground(new java.awt.Color(255, 204, 0));

        textArea.setColumns(20);
        textArea.setRows(5);
        guessPane.setViewportView(textArea);

        AB.setColumns(20);
        AB.setRows(5);
        ansPane.setViewportView(AB);

        tenChance.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 11)); // NOI18N
        tenChance.setForeground(new java.awt.Color(204, 0, 51));
        tenChance.setText("10次機會");

        noteReminder.setFont(new java.awt.Font("微軟正黑體", 0, 11)); // NOI18N
        noteReminder.setForeground(new java.awt.Color(153, 0, 51));
        noteReminder.setText("A數字&位置對，B數字對");

        javax.swing.GroupLayout midPaneLayout = new javax.swing.GroupLayout(midPane);
        midPane.setLayout(midPaneLayout);
        midPaneLayout.setHorizontalGroup(
            midPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(midPaneLayout.createSequentialGroup()
                .addGroup(midPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(guessPane, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(midPaneLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(tenChance, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(midPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ansPane, javax.swing.GroupLayout.DEFAULT_SIZE, 196, Short.MAX_VALUE)
                    .addComponent(noteReminder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        midPaneLayout.setVerticalGroup(
            midPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(midPaneLayout.createSequentialGroup()
                .addGroup(midPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tenChance)
                    .addComponent(noteReminder))
                .addGap(6, 6, 6)
                .addGroup(midPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ansPane, javax.swing.GroupLayout.DEFAULT_SIZE, 243, Short.MAX_VALUE)
                    .addComponent(guessPane)))
        );

        topPane.setBackground(new java.awt.Color(0, 51, 153));
        topPane.setBorder(new javax.swing.border.MatteBorder(null));

        topic.setFont(new java.awt.Font("Snap ITC", 0, 18)); // NOI18N
        topic.setForeground(new java.awt.Color(255, 0, 51));
        topic.setText("Guessing Game");
        topic.setToolTipText("");
        topic.setName(""); // NOI18N

        javax.swing.GroupLayout topPaneLayout = new javax.swing.GroupLayout(topPane);
        topPane.setLayout(topPaneLayout);
        topPaneLayout.setHorizontalGroup(
            topPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topPaneLayout.createSequentialGroup()
                .addGap(117, 117, 117)
                .addComponent(topic)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        topPaneLayout.setVerticalGroup(
            topPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, topPaneLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(topic, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)
                .addContainerGap())
        );

        bottomPane.setBackground(new java.awt.Color(255, 204, 0));

        send.setText("送出");
        send.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendActionPerformed(evt);
            }
        });

        newGame.setText("新遊戲");
        newGame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newGameActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout bottomPaneLayout = new javax.swing.GroupLayout(bottomPane);
        bottomPane.setLayout(bottomPaneLayout);
        bottomPaneLayout.setHorizontalGroup(
            bottomPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bottomPaneLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(bottomPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bottomPaneLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(send)
                        .addGap(18, 18, 18)
                        .addComponent(newGame))
                    .addComponent(guess))
                .addContainerGap())
        );
        bottomPaneLayout.setVerticalGroup(
            bottomPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bottomPaneLayout.createSequentialGroup()
                .addComponent(guess, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addGroup(bottomPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(send)
                    .addComponent(newGame)))
        );

        jMenu1.setText("Home");

        home.setText("Home Page");
        home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeActionPerformed(evt);
            }
        });
        jMenu1.add(home);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Rule");

        rule.setText("rule");
        rule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ruleActionPerformed(evt);
            }
        });
        jMenu2.add(rule);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(topPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(midPane, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(bottomPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(topPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(midPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bottomPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void sendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendActionPerformed
        String getText = guess.getText();
        int number = Integer.parseInt(getText);
        count++;
        textArea.append("guess " + count + ":" + getText + "\n");
        if (count == 10) {
            textArea.append("Game Over" + "\n新遊戲或關閉視窗");
            guess.setEditable(false);
            send.setVisible(false);
        }
        if (FrontPage.choice == 1) {
            this.comparisonEasy(number);
        } else if (FrontPage.choice == 2) {
            this.comparisonNormal(number);
        } else if (FrontPage.choice == 3) {
            this.comparisonHard(number);
        }
        guess.setText(null);
    }//GEN-LAST:event_sendActionPerformed

    private void newGameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newGameActionPerformed
        // TODO add your handling code here:
        textArea.setText(null);
        AB.setText(null);
        count = 0;
        send.setVisible(true);
        guess.setEditable(true);
        ///////////////////////////////////
        if (FrontPage.choice == 1) {
            this.createAns();
        } else if (FrontPage.choice == 2) {
            this.createAns();
        } else if (FrontPage.choice == 3) {
            this.createAns();
        }

    }//GEN-LAST:event_newGameActionPerformed

    private void homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeActionPerformed
        // TODO add your handling code here:
        new FrontPage().setVisible(true);
        super.dispose();
    }//GEN-LAST:event_homeActionPerformed

    private void ruleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ruleActionPerformed
        // TODO add your handling code here:
        new Rules().setVisible(true);
    }//GEN-LAST:event_ruleActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GameRun.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GameRun.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GameRun.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GameRun.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GameRun().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AB;
    private javax.swing.JScrollPane ansPane;
    private javax.swing.JPanel bottomPane;
    private javax.swing.JTextField guess;
    private javax.swing.JScrollPane guessPane;
    private javax.swing.JMenuItem home;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel midPane;
    private javax.swing.JButton newGame;
    private javax.swing.JLabel noteReminder;
    private javax.swing.JMenuItem rule;
    private javax.swing.JButton send;
    private javax.swing.JLabel tenChance;
    private javax.swing.JTextArea textArea;
    private javax.swing.JPanel topPane;
    private javax.swing.JLabel topic;
    // End of variables declaration//GEN-END:variables
}
