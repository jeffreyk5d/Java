package arraysetinclass;


import extendarray.Stack;




/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author fuchi
 */
public class TestStack1 {
    public static void main(String[] args) {
        Stack<Animal1> stack = new Stack<Animal1>();
        Animal1 a1 = new Animal1("dog");
        Animal1 a2 = new Animal1("cat");
        
        System.out.println("isEmpty:"+stack.isEmpty());
        stack.push(a1);    
        System.out.println("isEmpty:"+stack.isEmpty()); 
        stack.push(a2);
        stack.push(a1);
        stack.push(a2);       
        System.out.println("isFull:"+stack.isFull());
        System.out.println("pop:"+stack.pop());
        System.out.println("pop:"+stack.pop());
        System.out.println("pop:"+stack.pop());
        System.out.println("pop:"+stack.pop());
        System.out.println("pop:"+stack.pop());        
    }
}
