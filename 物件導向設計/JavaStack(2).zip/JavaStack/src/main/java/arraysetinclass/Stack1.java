package arraysetinclass;





import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author fuchi
 */
public class Stack1<E> {
    private int numOfStack=4;
    private int topIndex=0;
    private ArrayList<E> arrayList=new ArrayList<E>();
    public Stack1(int numOfStack) {
    }
    public Stack1() {
    }   
    public boolean push(E e) {
        if(this.isFull()){
            return false;
        }else{
            arrayList.add(e);
            topIndex++;
            return true;
        }                
    }
    public E pop() {
        if(this.isEmpty()){
            return null; 
        }else{            
            topIndex--;
            arrayList.remove(topIndex);                                    
            if(this.isEmpty()){
                return null; 
            }else{
                return arrayList.get(topIndex-1);
            }
            
        }                        
    }
    public E peek() {
        if(this.isEmpty()){
            return null;
        }else{
            return arrayList.get(topIndex-1);
        }        
    }        
    public boolean isFull() {
        if(this.numOfStack==this.topIndex){
            return true;
        }else{
            return false;                
        }
        
    }     
    public boolean isEmpty() {
        if(this.topIndex==0){
            return true;
        }else{
            return false;
        }        
    }
}
