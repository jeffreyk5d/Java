/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jason
 */
import java.util.Scanner;
public class score {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int score;
        System.out.println("Student Score:");
        score=in.nextInt();
        while(score>0){
            if(score>=60){
                System.out.println("Pass");
            }else if(score<60){
                System.out.println("Fail");
            }
            System.out.println("Student Score:");
            score=in.nextInt();
        }
        System.out.println("Exit Success");
        
        
    }
 
}
