/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;

/**
 *
 * @author TTUCSE
 */
public class Oval {
    public static int count=0;
    double semiMajorAxis;
    double semiMinorAxis;    
    public Oval() {
        count++;
    }

    public Oval(double semiMajorAxis, double semiMinorAxis) {
        this();
        this.semiMajorAxis = semiMajorAxis;
        this.semiMinorAxis = semiMinorAxis;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Oval.count = count;
    }

    public double getSemiMajorAxis() {
        return semiMajorAxis;
    }

    public void setSemiMajorAxis(double semiMajorAxis) {
        this.semiMajorAxis = semiMajorAxis;
    }

    public double getSemiMinorAxis() {
        return semiMinorAxis;
    }

    public void setSemiMinorAxis(double semiMinorAxis) {
        this.semiMinorAxis = semiMinorAxis;
    }
    
    public double ovalArea() {
        return this.semiMajorAxis*this.semiMinorAxis*Math.PI;
    }
    @Override
    public String toString() {
        return "Oval{" + "semiMajorAxis=" + semiMajorAxis + ", semiMinorAxis=" + semiMinorAxis +", ovalArea="+this.ovalArea()+ '}';
    }
    
}
