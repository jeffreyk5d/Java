/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p4;

/**
 *
 * @author TTUCSE
 */
public class Test {
    public static void main(String[] args) {
        
        Deck deck = new Deck();
        Deck.contructors(deck.card);
        System.out.println("Before shuffle:");
        Deck.toStrings(deck.card);
        Deck.shuffle(deck.card);
        System.out.println("");
        System.out.println("After shuffle:");
        Deck.toStrings(deck.card);
        
        
    }
}
