/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p4;

/**
 *
 * @author TTUCSE
 */
public class Deck {
    Card[] card = new Card[52];
    public static void contructors(Card[] cards) {
        
        for (int i = 0; i < 52; i++) {
            cards[i]=new Card();
        }
        int count=0;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 13; j++) {
                
                cards[count].setRank(j);
                cards[count].setSuit(i);
                count++;
            }            
        }        
    }
    public static void shuffle(Card[] allCards) {
        Card temp=new Card();                       
        for (int i = 0; i < allCards.length; i++) {
            int k;
            k=(int)(Math.random()*52);
            temp=allCards[i];
            allCards[i]=allCards[k];
            allCards[k]=temp;            
        }
    }
    public static void toStrings(Card[] cards) {
        for (int i = 0; i <cards.length; i++) {
            System.out.print(cards[i]);
            if(i%10==0){
                System.out.println("");
            }
        }
    }
    
}
