/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5;

/**
 *
 * @author TTUCSE
 */
public class Vehicle {
    private int price;
    private int vehicleID;
    private int licensePlateNo;

    public Vehicle() {
    }

    public Vehicle(int price, int vehicleID, int licensePlateNo) {
        this.price = price;
        this.vehicleID = vehicleID;
        this.licensePlateNo = licensePlateNo;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getVehicleID() {
        return vehicleID;
    }

    public void setVehicleID(int vehicleID) {
        this.vehicleID = vehicleID;
    }

    public int getLicensePlateNo() {
        return licensePlateNo;
    }

    public void setLicensePlateNo(int licensePlateNo) {
        this.licensePlateNo = licensePlateNo;
    }
    
    
}
