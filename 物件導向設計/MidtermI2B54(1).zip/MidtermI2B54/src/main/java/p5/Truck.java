/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5;

/**
 *
 * @author TTUCSE
 */
public class Truck extends Vehicle{
    private int noOfAxles;
    private int tonnage;

    public Truck() {
    }

    public Truck(int noOfAxles, int tonnage) {
        this.noOfAxles = noOfAxles;
        this.tonnage = tonnage;
    }

    public Truck(int noOfAxles, int tonnage, int price, int vehicleID, int licensePlateNo) {
        super(price, vehicleID, licensePlateNo);
        this.noOfAxles = noOfAxles;
        this.tonnage = tonnage;
    }

    public int getNoOfAxles() {
        return noOfAxles;
    }

    public void setNoOfAxles(int noOfAxles) {
        this.noOfAxles = noOfAxles;
    }

    public int getTonnage() {
        return tonnage;
    }

    public void setTonnage(int tonnage) {
        this.tonnage = tonnage;
    }

    @Override
    public String toString() {
        return "Truck{"+"Vehicle_id="+super.getVehicleID()+", Price="+super.getPrice()+" ,License_plate_no="+super.getLicensePlateNo()+ "noOfAxles=" + noOfAxles + ", tonnage=" + tonnage + '}';
    }
    
}
