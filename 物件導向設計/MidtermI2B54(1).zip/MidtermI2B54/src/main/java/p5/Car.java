/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5;

/**
 *
 * @author TTUCSE
 */
public class Car extends Vehicle{
    private int maxSpeed;
    private int noOfPassengers;

    public Car() {
    }

    public Car(int maxSpeed, int noOfPassengers) {
        this.maxSpeed = maxSpeed;
        this.noOfPassengers = noOfPassengers;
    }

    public Car(int maxSpeed, int noOfPassengers, int price, int vehicleID, int licensePlateNo) {
        super(price, vehicleID, licensePlateNo);
        this.maxSpeed = maxSpeed;
        this.noOfPassengers = noOfPassengers;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(int maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public int getNoOfPassengers() {
        return noOfPassengers;
    }

    public void setNoOfPassengers(int noOfPassengers) {
        this.noOfPassengers = noOfPassengers;
    }

    @Override
    public String toString() {
        return "Car{" +"Vehicle_id="+super.getVehicleID()+", Price="+super.getPrice()+" ,License_plate_no="+super.getLicensePlateNo()+ " ,maxSpeed=" + maxSpeed + ", noOfPassengers=" + noOfPassengers + '}';
    }
    
}
