/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5;

/**
 *
 * @author TTUCSE
 */
public class Test {
    public static void main(String[] args) {
        Car car = new Car(200,4,600000,0177,1234);
        Truck truck = new Truck(6,4,1300000,7765,5678);
        System.out.println(truck);
        System.out.println(car);
    }
}
