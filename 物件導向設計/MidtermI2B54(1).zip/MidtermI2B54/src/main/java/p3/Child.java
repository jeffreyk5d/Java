/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3;

/**
 *
 * @author TTUCSE
 */
public class Child extends Parent{
    private int n=20;

    public Child() {
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    @Override
    public String toString() {
        return "Child{" + "this=" + n +" super="+super.getN()+ '}';
    }
    
}
