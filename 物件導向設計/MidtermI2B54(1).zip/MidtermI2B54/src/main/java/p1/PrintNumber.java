/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import java.util.Scanner;

/**
 *
 * @author TTUCSE
 */
public class PrintNumber {
    public static void printNumber() {
        while(true){
            
            System.out.println("num=");
            Scanner in=new Scanner(System.in);            
            int n=in.nextInt();
            System.out.println("");
            if(n<0){
                break;
            }
            for (int i = 0; i <= n; i++) {
                System.out.print(3*i+1);
                System.out.println("");
        }
        }
        
    }
}
