/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class NumberSeperate {

    
    private int[] aguess={1,2,3,4};
    private int[] aguesss={1,2,3,4,5,6};
    public NumberSeperate() {
    }
    
    public NumberSeperate(int number, int length) {
        if (length == 4) {
            this.aguess[0] = number / 1000;
            this.aguess[1] = (number % 1000) / 100;
            this.aguess[2] = (number % 100) / 10;
            this.aguess[3] = (number % 10);
        } else if (length == 6) {            
            this.aguesss[0] = number / 100000;
            this.aguesss[1] = (number % 100000) / 10000;
            this.aguesss[2] = (number % 10000) / 1000;
            this.aguesss[3] = (number % 1000) / 100;
            this.aguesss[4] = (number % 100) / 10;
            this.aguesss[5] = (number % 10);
        }else{
            this.aguess[0]=1;
        }
    }

    public int[] getAguesss() {
        return aguesss;
    }

    public void setAguesss(int[] aguesss) {
        this.aguesss = aguesss;
    }

    public int[] getAguess() {
        return aguess;
    }

    public void setAguess(int[] aguess) {
        this.aguess = aguess;
    }

    @Override
    public String toString() {
        return "NumberSeperate{" + "aguess=" + aguess + '}';
    }
    

}
