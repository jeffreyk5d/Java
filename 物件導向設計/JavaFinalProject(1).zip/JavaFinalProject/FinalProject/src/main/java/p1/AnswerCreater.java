/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author User
 */
public class AnswerCreater extends GameObject {

    private int total;
    private ArrayList<Integer> ans = new ArrayList<>();

    public AnswerCreater() {
    }
    
    public AnswerCreater(int gameMode) {
        if (gameMode == 1) {
            //創造密碼0~9選4個
            ArrayList<Integer> storage = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                storage.add(i);
            }
            Collections.shuffle(storage);//0~9順序洗亂            
            this.ans.clear();
            //取a[0]~a[3]四個當作答案            
            for (int i = 0; i < 4; i++) {
                this.ans.add(storage.get(i));
            }
            this.total = this.ans.get(0) * 1000 + this.ans.get(1) * 100 + this.ans.get(2) * 10 + this.ans.get(3);
            if (total < 1000) {
                System.out.println("ans=0" + total);
            } else {
                System.out.println("ans=" + total);
            }
        } else if (gameMode == 2) {
            this.ans.clear();
            Random random = new Random();
            int[] ra = {random.nextInt(10), random.nextInt(10), random.nextInt(10), random.nextInt(10)};
            for (int i = 0; i < ra.length; i++) {
                ans.add(ra[i]);
            }
            this.total = this.ans.get(0) * 1000 + this.ans.get(1) * 100 + this.ans.get(2) * 10 + this.ans.get(3);
            //印答案時不會因為前面都是0 所以變成小於4digit的數字
            int length = (int) (Math.log10(total) + 1);
            System.out.println("\nans=");
            for (int i = 0; i < ans.size() - length; i++) {
                System.out.println("0");
            }            
            System.out.println(total);

        } else if (gameMode == 3) {
            this.ans.clear();
            Random random = new Random();

            int[] ra = {random.nextInt(10), random.nextInt(10), random.nextInt(10), random.nextInt(10), random.nextInt(10), random.nextInt(10)};
            for (int i = 0; i < ra.length; i++) {
                ans.add(ra[i]);
            }
            this.total = this.ans.get(0) * 100000 + this.ans.get(1) * 10000 + this.ans.get(2) * 1000 + this.ans.get(3) * 100 + this.ans.get(4) * 10 + this.ans.get(5);
            //印答案時不會因為前面都是0 所以變成小於6digit的數字
            int length = (int) (Math.log10(total) + 1);
            System.out.println("\nans=");
            for (int i = 0; i < ans.size() - length; i++) {
                System.out.println("0");
            }
            System.out.println(total);
        }

    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public ArrayList<Integer> getAns() {
        return ans;
    }

    public void setAns(ArrayList<Integer> ans) {
        this.ans = ans;
    }

    @Override
    public String toString() {
        return "AnswerCreater{" + "total=" + total + ", ans=" + ans + '}';
    }

}
