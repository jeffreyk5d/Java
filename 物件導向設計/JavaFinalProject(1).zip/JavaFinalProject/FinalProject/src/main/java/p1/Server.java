/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
class ServerHelper extends Thread {

    private static int clientNum = 0;
    private Socket clientSocket;
    private InputStream input;
    private OutputStream output;

    public ServerHelper(Socket clientSocket) {
        clientNum++;
        try {
            this.clientSocket = clientSocket;
            input = this.clientSocket.getInputStream();
            output = this.clientSocket.getOutputStream();
        } catch (IOException ex) {
            Logger.getLogger(ServerHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void run() {
//        DataInputStream din;
        System.out.println("ServerHelper " + clientNum + " is running!!!");
        System.out.println("---------------------------------------");
        new FrontPage().setVisible(true);
//        din = new DataInputStream(input);
//        DataOutputStream dout = new DataOutputStream(output);
    }
}

public class Server {

    Socket s;

    public static void main(String[] args) throws IOException {
        Server server = new Server();
        server.startServer();
    }

    private void startServer() throws IOException {
        int port = 8004;

        ServerSocket server = new ServerSocket(port);
        System.out.println("Server is Ready~~~~");
        while (true) {
            s = server.accept();
            ServerHelper serverHelper = new ServerHelper(s);
            serverHelper.start();
        }
    }
}
