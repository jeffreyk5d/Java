/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class Comparer extends GameObject {

    private int A = 0;
    private int B = 0;

    public Comparer() {
    }
    
    public Comparer(ArrayList<Integer> ans, int[] aguess, int choice) {
        if (choice == 1 || choice == 2) {
            int[] tag = {0, 0, 0, 0};
            for (int i = 0; i < aguess.length; i++) {
                if (aguess[i] == ans.get(i)) {
                    A++;
                    tag[i] = 1;
                }
            }
            for (int i = 0; i < aguess.length; i++) {
                for (int j = 0; j < aguess.length; j++) {
                    if (aguess[i] == ans.get(j) && tag[j] != 1) {
                        tag[j] = 1;
                        B++;
                        break;
                    }
                }
            }
        } else if (choice == 3) {
            int[] tag = {0, 0, 0, 0, 0, 0};
            for (int i = 0; i < aguess.length; i++) {
                if (aguess[i] == ans.get(i)) {
                    A++;
                    tag[i] = 1;
                }
            }
            for (int i = 0; i < aguess.length; i++) {
                for (int j = 0; j < aguess.length; j++) {
                    if (aguess[i] == ans.get(j) && tag[j] != 1) {
                        tag[j] = 1;
                        B++;
                        break;
                    }
                }
            }
        }

    }

    public int getA() {
        return A;
    }

    public void setA(int A) {
        this.A = A;
    }

    public int getB() {
        return B;
    }

    public void setB(int B) {
        this.B = B;
    }
}
