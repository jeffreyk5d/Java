/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class somethingAboutComparing {
    public static int  a;
    public static char  b;
    public static void main(String[] args) {
        int[] array={55,88,4165,12,34,3};
        System.out.println("max="+function.max(array));
        System.out.println("min="+function.min(array));
        System.out.println("oringinal:");
        function.printArray(array);
        System.out.println("sorted:");
        function.bubble(array);
        function.printArray(array);
        System.out.println("a:"+a);
        System.out.println("b:"+b);
    }        
}
