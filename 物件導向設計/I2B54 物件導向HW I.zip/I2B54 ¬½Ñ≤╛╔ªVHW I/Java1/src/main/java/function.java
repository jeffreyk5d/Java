/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class function {
    public static void printArray(int[] array) {
        for (int o = 0; o < array.length; o++) {
            System.out.println(array[o]);
        }
    }
    public static int max(int[] array) {
        int m=array[0];
        for (int i = 0; i < array.length; i++) {
            if(m<array[i]){
                m=array[i];
            }            
        }
        return m;        
    }
    public static int min(int[] array) {
        int m=array[0];
        for (int i = 0; i < array.length; i++) {
            if(m>array[i]){
                m=array[i];
            } 
        }
        return m;        
    }
    public static void bubble(int[] array) {
        int temp=0;
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array.length-1; j++) {
                if(array[i]<array[j]){
                  temp=array[i];
                  array[i]=array[j];
                  array[j]=temp;
                }
            }       
        }
        
    }    
}
