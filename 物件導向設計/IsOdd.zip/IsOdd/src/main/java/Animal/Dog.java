/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animal;

/**
 *
 * @author TTUCSE
 */
public class Dog extends Animal{
    boolean iswild;

    public Dog() {
    }

    public Dog(boolean iswild) {
        this.iswild = iswild;
    }

    public Dog(boolean iswild, int weight) {
        super(weight);
        this.iswild = iswild;
    }

    public boolean isIswild() {
        return iswild;
    }

    public void setIswild(boolean iswild) {
        this.iswild = iswild;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "Dog{"+"weight=" +super.weight+ "  iswild=" + iswild + '}';
    }
    
    
}
