/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TTUCSE
 */
public class Test {
    public static void main(String[] args) {
        int n=15;
        System.out.println("n=15");
        System.out.println("n is odd "+FindOdd.isOdd(n));
        int b=4;
        System.out.println("b=4");
        System.out.println("b is odd "+FindOdd.isOdd(b));
    }
}
