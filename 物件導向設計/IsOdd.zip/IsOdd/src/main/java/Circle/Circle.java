/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Circle;

/**
 *
 * @author TTUCSE
 */
public class Circle {
    private static final double pi= 3.14;
    private int radius;

    public Circle() {
    }

    public Circle(int radius) {
        this.radius = radius;
    }




    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }
    
    public static double perimeter(int r) {
        double answer=2*(double)r*pi;
        return answer;
    }
    public static double area(int r) {
        double answer=(double)r*(double)r*pi;
        return answer;
    }

    @Override
    public String toString() {
        return "Circle{" + "radius=" + radius +"area="+area(radius)+"perimeter"+perimeter(radius)+ '}';
    }
    
    
}
