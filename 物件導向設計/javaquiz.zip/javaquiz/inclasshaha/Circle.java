/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.inclasshaha;

/**
 *
 * @author TTUCSE
 */
public class Circle {
    private float radius;
    private final static double PI=3.14159;
    private static int count;

    public Circle() {
        count++;
    }

    public Circle(float radius) {
        this.radius = radius;
    }

    public float getRadius() {
        return radius;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Circle.count = count;
    }
    public  float getArea(float radius) {
        return (float)Math.PI*radius*radius;
    }
    public  float getPerimeter(float radius) {
        return (float)Math.PI*radius*2;
    }

    @Override
    public String toString() {
        return "Circle{" + "radius=" + radius + '}';
    }

    void setRadius() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
