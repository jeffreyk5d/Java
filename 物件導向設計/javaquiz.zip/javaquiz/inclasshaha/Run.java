/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.inclasshaha;

/**
 *
 * @author TTUCSE
 */
public class Run {
    
    public static void main(String[] args) {
        Circle C1=new Circle();
        Circle C2=new Circle();
        Circle C3=new Circle();        
        C2.setRadius(25);
        C3.setRadius(125);
        System.out.println(" C1Area="+C1.getArea(C1.getRadius())+" C1Perimeter="+C1.getPerimeter(C1.getRadius()));
        System.out.println(" C2Area="+C2.getArea(C2.getRadius())+" C2Perimeter="+C2.getPerimeter(C2.getRadius()));
        System.out.println(" C3Area="+C3.getArea(C3.getRadius())+" C3Perimeter="+C3.getPerimeter(C3.getRadius()));
        
    }
}
