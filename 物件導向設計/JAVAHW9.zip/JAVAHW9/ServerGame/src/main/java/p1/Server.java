/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
class ServerHelper extends Thread {

    private static int clientNum = 0;
    private Socket clientSocket;
    private InputStream input;
    private OutputStream output;

    public ServerHelper(Socket clientSocket) {
        clientNum++;
        try {
            this.clientSocket = clientSocket;
            input = this.clientSocket.getInputStream();
            output = this.clientSocket.getOutputStream();
        } catch (IOException ex) {
            Logger.getLogger(ServerHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void run() {
        DataInputStream din;
        System.out.println("ServerHelper " + clientNum + " is running!!!");
        System.out.println("---------------------------------------");
        try {
            din = new DataInputStream(input);
            DataOutputStream dout = new DataOutputStream(output);
            //創造密碼0~9選4個
            ArrayList<Integer> storage = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                storage.add(i);
            }
            Collections.shuffle(storage);//0~9順序洗亂
            ArrayList<Integer> ans = new ArrayList<>();
            //取a[0]~a[3]四個當作答案
            for (int i = 0; i < 4; i++) {
                ans.add(storage.get(i));
            }
            int total = ans.get(0) * 1000 + ans.get(1) * 100 + ans.get(2) * 10 + ans.get(3);
            if(total<1000){
                System.out.println("ans=0"+total);
            }else{
                System.out.println("ans=" + total);
            }
            
            while (true) {
                int guess = din.readInt();
                System.out.println("guess=" + guess);
                if (guess < 0) {
                    break;
                }
                int A = 0, B = 0;
                int[] aguess={1,2,3,4};
                aguess[0] = guess / 1000;
                aguess[1] = (guess % 1000) / 100;
                aguess[2] = (guess % 100) / 10;
                aguess[3] = (guess % 10);
                //找B
                for (int i = 0; i < aguess.length; i++) {
                    if (ans.contains(aguess[i])) {
                        B++;
                    }
                }
                //找A如果找到則B-- (A優先級大於B)
                for (int i = 0; i < aguess.length; i++) {
                    if (aguess[i] == ans.get(i)) {
                        A++;
                        B--;
                    }
                }
                if(A==4){
                    dout.writeInt(A);
                    dout.writeInt(B);
                    System.out.println("You Win!!");                    
                    break;
                }else{
                    System.out.println("Again "+A+B);
//                    dout.writeUTF("Again");
                    dout.writeInt(A);
                    dout.writeInt(B);
                }
                
            }
            System.out.println("ServerHelper"+clientNum+"is closing...");
            System.out.println("------------------------------------------");

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

public class Server {

    Socket s;

    public static void main(String[] args) throws IOException {
        Server server = new Server();
        server.startServer();
    }

    private void startServer() throws IOException {
        int port = 8004;

        ServerSocket server = new ServerSocket(port);
        System.out.println("Server is Ready~~~~");
        while (true) {
            s = server.accept();
            ServerHelper serverHelper = new ServerHelper(s);
            serverHelper.start();
        }
    }
}
